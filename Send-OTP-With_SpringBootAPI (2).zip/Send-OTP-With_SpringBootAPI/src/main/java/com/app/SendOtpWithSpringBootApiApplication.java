package com.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SendOtpWithSpringBootApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SendOtpWithSpringBootApiApplication.class, args);
		System.out.println("welcome to springBoot");
	}

}
