package com.app.dto;

//used to store temporary variable, it is a moto class

public class SmsPojo {
	private String phoneNo;

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	
	

}
