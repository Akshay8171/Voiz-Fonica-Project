package com.app.dto;

public class StoreOTP {
	
	private static int otp; // used to store OTP

	public static int getOtp() {
		return otp;
	}

	public static void setOtp(int otp) {
		StoreOTP.otp = otp;
	}
	

}
