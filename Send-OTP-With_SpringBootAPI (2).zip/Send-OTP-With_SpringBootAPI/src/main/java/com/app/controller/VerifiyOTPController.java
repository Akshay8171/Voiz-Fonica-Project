package com.app.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.StoreOTP;
import com.app.dto.TempOTP;

@RestController

public class VerifiyOTPController {
	
	@PostMapping("/otp")
	public String verifyOTP(@RequestBody TempOTP sms) { 
		if(sms.getOtp()==StoreOTP.getOtp())
			// StoreOTP.getOtp() is the otp stored in server
			//sms.getOtp() is the otp we are entering
		return "You have entered the Correct OTP";
		else
			return "You have entered the Wrong OTP";
		
	}

}
