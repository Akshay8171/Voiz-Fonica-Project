package com.app.service;

import java.text.ParseException;

import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;

import com.app.dto.SmsPojo;
import com.app.dto.StoreOTP;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
@Component
public class SmsService {
private   final String aid="ACefb3af7c4a6e5186d6b02e40de8b0328";  //Account SID
private  final String at= "1fcc11d9ae946b1d2d9314d85707dd4e";   //Auto Token
private final String  ph="+12058914158";  //from this mobile number we are sending the otp
public  void   send(SmsPojo  sms) throws   ParseException
{
        Twilio.init(aid, at);  //calling account sid and auth token
        int min=100000;
        int max=999999;
        int number=(int)(Math.random()*(max-min+1)+min);  //storing otp in number
        String msg="Your OTP - " +number+
                " Please Verify the OTP  "+
                 "Regards- Nisarga MR";
        Message message=Message.creator(new PhoneNumber(sms.getPhoneNo()),
            new PhoneNumber(ph),msg).create();  //message is a object to store the phone number to which we wanted to send otp
        
        StoreOTP.setOtp(number);

}
public  void  receieve(MultiValueMap<String,String> smlscallback)
{

}
}