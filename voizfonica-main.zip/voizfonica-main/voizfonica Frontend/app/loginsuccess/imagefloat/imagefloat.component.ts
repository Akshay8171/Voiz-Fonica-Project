import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imagefloat',
  templateUrl: './imagefloat.component.html',
  styleUrls: ['./imagefloat.component.css']
})
export class ImagefloatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
