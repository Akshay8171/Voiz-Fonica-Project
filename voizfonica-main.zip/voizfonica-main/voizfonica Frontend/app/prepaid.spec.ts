import { Prepaid } from './prepaid';

describe('Prepaid', () => {
  it('should create an instance', () => {
    expect(new Prepaid()).toBeTruthy();
  });
});
