export class Postpaid {
    id:number;
    emailId:String;
    userName:String;
    password:number;
}
