import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foot2',
  templateUrl: './foot2.component.html',
  styleUrls: ['./foot2.component.css']
})
export class Foot2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
