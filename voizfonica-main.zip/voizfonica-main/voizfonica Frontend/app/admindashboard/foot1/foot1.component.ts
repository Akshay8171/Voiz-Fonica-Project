import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foot1',
  templateUrl: './foot1.component.html',
  styleUrls: ['./foot1.component.css']
})
export class Foot1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
