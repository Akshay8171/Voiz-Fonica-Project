import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footernew',
  templateUrl: './footernew.component.html',
  styleUrls: ['./footernew.component.css']
})
export class FooternewComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
