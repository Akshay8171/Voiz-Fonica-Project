import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bg',
  templateUrl: './bg.component.html',
  styleUrls: ['./bg.component.css']
})
export class BgComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
