export class Payment {
    id:number;
    name:string;
    benifits:string;
    emailId:string;
    phone:number;
    cost:number;
    validity:number;
    service:string;
}
