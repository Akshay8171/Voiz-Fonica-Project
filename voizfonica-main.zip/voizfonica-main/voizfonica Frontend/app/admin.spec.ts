import { Admins } from './admin';

describe('Admins', () => {
  it('should create an instance', () => {
    expect(new Admins()).toBeTruthy();
  });
});
