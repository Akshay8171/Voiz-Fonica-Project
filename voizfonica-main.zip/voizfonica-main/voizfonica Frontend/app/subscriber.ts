export class Subscriber {

    id:number;
   emailId:string;
   userName:string;
   password:string;
   typeOfSubscriber:string;
   mobileNum:string;
   constructor() {}
}
