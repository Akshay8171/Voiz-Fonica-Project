import { Subscriber } from './subscriber';

describe('Subscriber', () => {
  it('should create an instance', () => {
    expect(new Subscriber()).toBeTruthy();
  });
});
