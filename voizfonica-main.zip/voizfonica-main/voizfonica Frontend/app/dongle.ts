export class Dongle {
    id:number;
    emailId:String;
    userName:String;
    password:number;
}
