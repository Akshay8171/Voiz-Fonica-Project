export class OTP {
    otp:String;
    
      constructor(){
          
      }
  }
  