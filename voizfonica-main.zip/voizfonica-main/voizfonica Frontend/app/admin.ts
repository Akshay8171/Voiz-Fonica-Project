export class Admins {
    adminId: number;
    firstName: String;
    lastName: String;
    gender:String;
    email: String;
    mobileNumber: number;
    adharNumber: number;
    password:String;
    constructor(){}

}
