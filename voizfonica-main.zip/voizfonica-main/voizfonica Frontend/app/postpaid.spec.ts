import { Postpaid } from './postpaid';

describe('Postpaid', () => {
  it('should create an instance', () => {
    expect(new Postpaid()).toBeTruthy();
  });
});
