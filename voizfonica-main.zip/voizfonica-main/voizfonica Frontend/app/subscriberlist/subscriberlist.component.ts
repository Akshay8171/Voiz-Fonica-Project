import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-subscriberlist',
  templateUrl: './subscriberlist.component.html',
  styleUrls: ['./subscriberlist.component.css']
})
export class SubscriberlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
