import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pretopost',
  templateUrl: './pretopost.component.html',
  styleUrls: ['./pretopost.component.css']
})
export class PretopostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
