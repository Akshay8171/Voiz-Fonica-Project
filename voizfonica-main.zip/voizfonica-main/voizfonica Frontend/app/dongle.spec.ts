import { Dongle } from './dongle';

describe('Dongle', () => {
  it('should create an instance', () => {
    expect(new Dongle()).toBeTruthy();
  });
});
