export class History {
    id: number;
    price: number;
    rechargeDate: string;
    data: number;

    constructor() {
        
    }
}
