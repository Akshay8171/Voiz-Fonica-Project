//import { timeStamp } from 'console';

export class User {
     id:number;
     firstName: string;
     lastName: string;
      type: string;
    email: string;
     mobileNumber: number;
     adharNumber: number;
     gender: string;
    password: string;
  newpassword: string;
  
     constructor()
     {
     }

     }

