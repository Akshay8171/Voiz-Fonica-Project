import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paysuccess',
  templateUrl: './paysuccess.component.html',
  styleUrls: ['./paysuccess.component.css']
})
export class PaysuccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
