# UPDATED FRONTEND CODE AVAILABLE IN MASTER BRANCH
# voizfonica

  Minimum System Requirements:
  i5 Processor or New Gen AMD Ryzen, 8 GB RAM, SSD instead of Hard disk.

# voizfonica Backend:
  Requirements: STS(Spring tool suit) , MYSQL DATABASE with JAVA JDK v1.8.
  
  open the sts-> import project-> existing maven project, tick add project into workspace -> then click ok.
  
  open the mysql and create a database as a test.
  
  open the application properties in the sts, change the username and password for mysql database as per your computer.
  
  The Dependency for Spring all mentioned in the POM.XML file. Need a good Internet connection with High speed SSD for faster Experience.
  
  
  
# voizfonica Frontend:
  
  Requirements: Angular CLI, Node js, Node js Package manager.
  
  * -> ng new Projectname <-
  *-> cd Projectname <-
  * ->code . <-   (to open the project in vscode put)
  
  open the project in vs code and then delete the files in the src folder and paste the files from the github(voizfonica frontend).
  
  then open the vs code. 
  
  open the terminal and then put -> ng serve <- .
  
  then the server will start.
  
  to check that open the localhost:4200/home in the browser.
  
  
  
