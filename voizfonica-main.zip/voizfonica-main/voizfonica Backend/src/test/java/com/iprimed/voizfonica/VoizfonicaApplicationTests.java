//package com.iprimed.voizfonica;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class VoizfonicaApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
